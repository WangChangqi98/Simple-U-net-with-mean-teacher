#把图片变成两种像素值，0和255
import os
import scipy
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np
for k in range(467,499):
    im = Image.open('C:\\Users\\卡卡瓶\\Desktop\\深度学习\\VOC_Thyroid\\Segmentations\\%d.jpg'%k)
    pix = im.load()#导入像素
    width = im.size[0]#获取宽度
    height = im.size[1]#获取长度

    for x in range(width):
        for y in range(height):
            r,g,b = im.getpixel((x,y))
            
            rgb = (r,g,b)
            if(b<127):
                im.putpixel((x,y),(0,0,0))
            else:
                im.putpixel((x,y),(255,255,255))
            

    im = im.convert('L')
    im.save('%d.png'%k)

"""
print(im.mode)
#输出图片像素值
im = np.array(im)

print(np.unique(im))
"""
